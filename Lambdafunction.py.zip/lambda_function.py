import json
import boto3
import uuid  # Added for better unique filenames

def lambda_handler(event, context):
    # Parse the event payload; using body to simulate API-style events
    try:
        body = json.loads(event.get('body', '{}'))
    except Exception as e:
        return {
            "statusCode": 400,
            "headers": cors_headers(),
            "body": json.dumps({"error": "Invalid JSON", "message": str(e)})
        }
    
    text = body.get('text')
    voice_id = body.get('voice', 'Joanna')  # Default voice is Kevin
    
    # Generate a unique filename using UUID
    filename = f"output/{uuid.uuid4()}.mp3"
    bucket_name = "text-tospeech-bucket"  # Hardcoded bucket name
    
    if not text:
        return {
            "statusCode": 400,
            "headers": cors_headers(),
            "body": json.dumps({"error": "Missing text"})
        }
    
    polly_client = boto3.client('polly')
    s3_client = boto3.client('s3')
    
    try:
        # Synthesize the speech using Amazon Polly with the selected voice
        response = polly_client.synthesize_speech(
            Text=text,
            OutputFormat='mp3',
            VoiceId=voice_id,
            Engine='standard'
        )
        
        if "AudioStream" not in response:
            raise Exception("No audio stream found in Polly response.")
        
        # Upload the resulting MP3 file to S3
        s3_client.put_object(
            Bucket=bucket_name,
            Key=filename,
            Body=response['AudioStream'].read(),
            ContentType="audio/mpeg"
        )
        
        # Generate a pre-signed URL valid for 1 hour (3600 seconds)
        presigned_url = s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket': bucket_name, 'Key': filename},
            ExpiresIn=3600
        )
        
        return {
            "statusCode": 200,
            "headers": cors_headers(),
            "body": json.dumps({
                "message": "Audio generated successfully!",
                "audioUrl": presigned_url
            })
        }
        
    except Exception as e:
        return {
            "statusCode": 500,
            "headers": cors_headers(),
            "body": json.dumps({
                "error": "Processing failed",
                "message": str(e)
            })
        }

# CORS headers function
def cors_headers():
    return {
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
    }

